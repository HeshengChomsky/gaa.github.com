#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2019-12-17 16:06
# @Author  : shaoguang.csg
# @File    : model_dataset

import imp
from re import S
import re
import tensorflow as tf
import numpy as np
import json
from util.util import *
from tensorflow.contrib.lookup.lookup_ops import  get_mutable_dense_hashtable
from nets import BCQ_net, Mix_net
# from tensorflow.contrib.opt import HashAdamOptimizer
from tensorflow.core.framework import types_pb2
from tensorflow_serving.apis import predict_pb2
import os
import sys
CURRENT_DIR = os.path.split(os.path.abspath(__file__))[0]  # 当前目录
config_path = CURRENT_DIR.rsplit('/', 2)[0]  # 上2级目录
sys.path.append(config_path)
# from rl_easy_go_high.rl_code.main import Trainer

logger = set_logger()

def load_normalization_parameter(mean_var_filename, fea_num, prod_num=4,use_bcorle=False):
    fea_mean = []
    fea_var = []
    input_file = tf.gfile.Open(mean_var_filename)
    for line in input_file:
        splitted = line.strip().split("\t")
        for i in range (len(splitted)):
            if splitted[i] == "NULL":
                splitted[i] = 1.0

        for i in range(fea_num):
            fea_mean.append(float(splitted[i]))
        for i in range(fea_num):
            fea_var.append(float(splitted[i + fea_num]))
        if use_bcorle:
            fea_mean.append(1.0)
            fea_var.append(1.0)
        break
    logger.info('num_fea_mean %s', fea_mean)
    logger.info('num_fea_var %s', fea_var)
   
    fea_mean = [[i for _ in range(prod_num)] for i in fea_mean]
    fea_var = [[i for _ in range(prod_num)] for i in fea_var]
    return fea_mean, fea_var



def ortho_init(scale=1.0):
    # belsopenai baselines 用到的初始化函数
    def _ortho_init(shape, dtype, partition_info=None):
        # lasagne ortho init for tf
        shape = tuple(shape)
        if len(shape) == 2:
            flat_shape = shape
        elif len(shape) == 4:  # assumes NHWC
            flat_shape = (np.prod(shape[:-1]), shape[-1])
        else:
            raise NotImplementedError
        a = np.random.normal(0.0, 1.0, flat_shape)
        u, _, v = np.linalg.svd(a, full_matrices=False)
        q = u if u.shape == flat_shape else v  # pick the one with the correct shape
        q = q.reshape(shape)
        return (scale * q[:shape[0], :shape[1]]).astype(np.float32)

    return _ortho_init


def make_coeff(num_heads):
    arr = np.random.uniform(low=0.0, high=1.0, size=num_heads)
    arr /= np.sum(arr)
    return arr
 

def inference_rbcq(name, state_, hidden_units_list, num_actions, use_bn, use_rem, num_heads, random_coeff,trainable):
    with tf.variable_scope(name + '_net'):
        net = state_
        if use_bn:
            net = tf.layers.batch_normalization(state_, axis=-1, momentum=0.99,
                                                epsilon=0.001,
                                                center=True,
                                                scale=True,
                                                beta_initializer=tf.zeros_initializer(),
                                                gamma_initializer=tf.ones_initializer(),
                                                moving_mean_initializer=tf.zeros_initializer(),
                                                moving_variance_initializer=tf.ones_initializer(),
                                                beta_regularizer=None,
                                                gamma_regularizer=None,
                                                beta_constraint=None,
                                                gamma_constraint=None,
                                                training=False,
                                                trainable=trainable,
                                                reuse=None,
                                                renorm=False,
                                                renorm_clipping=None,
                                                renorm_momentum=0.99,
                                                fused=None,
                                                name="bn"
                                                )
        with tf.variable_scope(name + 'q_net'):
            q_net = net
            for i in range(len(hidden_units_list)):
                q_net = tf.layers.dense(
                    inputs=q_net,
                    activation=tf.nn.relu,
                    units=hidden_units_list[i],
                    kernel_initializer=ortho_init(),
                    trainable=trainable,
                    name='fc_{idx}'.format(idx=i)
                )

            if use_rem:
                q = tf.layers.dense(q_net, num_actions * num_heads, activation=None, name="head_1", trainable=trainable)
                q = tf.reshape(q, (tf.shape(q_net)[0], num_actions, num_heads), name='head_2')
                q = tf.squeeze(tf.reduce_sum(q * tf.reshape(random_coeff, [1, 1, -1]), axis=2), name="head_q")
            else:
                q = tf.layers.dense(q_net, num_actions, activation=None, name="head_q", trainable=trainable)

        with tf.variable_scope(name + 'i_net'):
            # I network
            i_net = net
            for i in range(len(hidden_units_list)):
                i_net = tf.layers.dense(
                    inputs=i_net,
                    activation=tf.nn.relu,
                    units=hidden_units_list[i],
                    kernel_initializer=ortho_init(),
                    trainable=trainable,
                    name='fc_{idx}'.format(idx=i)
                )
            i = tf.layers.dense(i_net, num_actions, activation=None, name="i_o", trainable=trainable)
        imt = tf.nn.log_softmax(i)
    return q, imt, i


def Smooth_L1_Loss(labels, predictions, name, is_weights):
    with tf.variable_scope(name):
        diff = tf.abs(labels - predictions)
        less_than_one = tf.cast(tf.less(diff, 1.0), tf.float32)  # Bool to float32
        smooth_l1_loss = (less_than_one * 0.5 * diff ** 2) + (1.0 - less_than_one) * (diff - 0.5)
        return tf.reduce_mean(is_weights * smooth_l1_loss)  # get the average


def loss_function(y_logits, y_true):
    with tf.name_scope('loss'):
        cross_entropy_loss = tf.nn.sigmoid_cross_entropy_with_logits(
            labels=y_true,
            logits=y_logits,
            name='xentropy'
        )
        loss = tf.reduce_mean(cross_entropy_loss, name='xentropy_mean')
    return loss


optimizer_mapping = {
    "adam": tf.train.AdamOptimizer,
    "adadelta": tf.train.AdadeltaOptimizer,
    "adagrad": tf.train.AdagradOptimizer,
    "sgd": tf.train.GradientDescentOptimizer,
    "rmsprop": lambda lr: tf.train.RMSPropOptimizer(learning_rate=lr, momentum=0.95)
}


def get_optimizer_by_name(name):
    if name not in optimizer_mapping.keys():
        logger.error("Unsupported {} currently, using sgd as default".format(name))
        return optimizer_mapping["sgd"]
    return optimizer_mapping[name]

@tf.function
def select_action(q, imt, threshold, use_bcq,lambda_vector=None,batch=False):
    return_shape = [-1,4] if batch else [-1,1]
    argmax_axis = 2 if batch else 1
    if lambda_vector is not None:
        new_q  = q - lambda_vector
    else:
        new_q = q 
    if use_bcq:
        imt = tf.exp(imt)
        imt = (imt / tf.reduce_max(imt, axis=1, keep_dims=True) >= threshold)
        imt = tf.cast(imt, dtype=tf.float32)
        return tf.reshape(tf.argmax(imt * new_q + (1. - imt) * -1e8, axis=argmax_axis), return_shape), tf.reshape(
            tf.reduce_max(imt * new_q + (1. - imt) * -1e8, axis=argmax_axis), return_shape)
    else:
        return tf.reshape(tf.argmax(new_q, axis=argmax_axis), return_shape), tf.reshape(
            tf.reduce_max(new_q, axis=argmax_axis), return_shape)


def model_fn(features, labels, mode, params):
    vocab_size = params['vocab_size']
    state_fea_num = params['state_fea_num']
    deep_layers = params['deep_layers'].split(',')
    learning_rate = params['learning_rate']
    update_interval = params['update_interval']
    num_action = params['num_action']
    embed_dim = params['embed_dim']
    ext_is_predict_serving = params['ext_is_predict_serving']
    threshold = params['threshold']
    i_loss_weight = params['i_loss_weight']
    i_regularization_weight = params['i_regularization_weight']
    q_loss_weight = params['q_loss_weight']
    gamma = params['gamma']
    num_heads = params['num_heads']
    use_rem = params['use_rem']
    use_bcq = params['use_bcq']
    use_bn = params['use_bn']
    use_dense_hashtable=params['use_dense_hashtable']
    cate_fea_num = params['cate_fea_num']
    use_cate_fea=params['use_cate_fea']
    prod_num = params['prod_num']
    use_adaptive = params['use_adaptive']
    use_batch_loss = params['use_batch_loss']

    if use_adaptive:
        lambda_update_interval = params['lambda_update_interval']
        lambda_budgets_target =  [float(s) for s in params["lambda_budgets_target"].split("_")]
        auto_lambda_vector = tf.get_variable('auto_lambda_vector', shape=[4], dtype=tf.float32,
                                                initializer=tf.zeros_initializer(), trainable=False)
        target_auto_lambda_vector = tf.get_variable('target_auto_lambda_vector', shape=[4], dtype=tf.float32,
                                                        initializer=tf.zeros_initializer(), trainable=False)

    cur_state_dynamic_fea_mean_var_filename = params['cur_state_dynamic_fea_mean_var_filename']
    next_state_dynamic_fea_mean_var_filename = params['next_state_dynamic_fea_mean_var_filename']

    logger.info('cur_state_dynamic_fea_mean_var_filename {}'.format(cur_state_dynamic_fea_mean_var_filename))
    logger.info('next_state_dynamic_fea_mean_var_filename {}'.format(next_state_dynamic_fea_mean_var_filename))
    logger.info('params {}'.format(params))

    with tf.name_scope('model'):
        poi_id = features['poi_id']
        #prod = tf.cast(features['prod'] , tf.int32)
        #prod = tf.subtract(prod, 1)
        total_budgets = features['total_budgets']
        # state:[batch_size, prod_size, fea_num]
        if(use_cate_fea):
            cur_state_cate_fea_col = tf.cast(features['cur_state_cate_fea'],tf.string)
            #next_state_cate_fea_col = tf.cast(features['next_state_cate_fea'],tf.string)
        cur_state_dynamic_fea_col = features['cur_state_dynamic_fea']
        #next_state_dynamic_fea_col = features['next_state_dynamic_fea']

        reward = tf.cast(features['reward'], tf.float32)
        logger.info('labels {}'.format(labels))
        action_col = tf.cast(features['action'],tf.int64)
        logger.info('action_col {}'.format(action_col))

        is_terminal = tf.cast(tf.concat([tf.zeros_like(action_col[:,:3]),tf.ones_like(tf.expand_dims(action_col[:,3],axis=1))],axis=1),tf.float32)


        with tf.name_scope('dict'):
            # num_fea_mean_vec, num_fea_var_vec = load_normalization_parameter(
            #     num_fea_mean_var_filename,
            #     num_fea_num
            # )
            cur_state_dynamic_mean_vec, cur_state_dynamic_var_vec = load_normalization_parameter(
                cur_state_dynamic_fea_mean_var_filename,
                state_fea_num,
                prod_num
            )
            # next_state_dynamic_mean_vec, next_state_dynamic_var_vec = load_normalization_parameter(
            #     next_state_dynamic_fea_mean_var_filename,
            #     state_fea_num,
            #     prod_num
            # )
        if(use_cate_fea):
            with tf.name_scope('variable'):
                if(use_dense_hashtable):
                    print("get_mutable_dense_hashtable!!!!!!")
                    embedding_matrix = get_mutable_dense_hashtable(key_dtype=tf.int64,
                                                    value_dtype=tf.float32,
                                                    shape=tf.TensorShape([embed_dim]),
                                                    name="embed_table",
                                                    initializer=tf.truncated_normal_initializer(0.0, 1e-2),
                                                    shard_num=2)
                else:
                    print("get_variable!!!!!!")
                    embedding_matrix = tf.get_variable(
                            'embeddings',
                            shape=[vocab_size, embed_dim],
                            trainable=True,
                        )


        with tf.name_scope('input'):
            # poi static feature
            if(use_cate_fea):
                # id_prefix=tf.constant([[str(i) for i in range(cate_fea_num)] for j in range(shape[0])],dtype=tf.string)


                prefix = tf.constant([str(i)+"_"  for i in range(cate_fea_num)]) 
                # cur_state_cate_fea_col= prefix+cur_state_cate_fea_col
                # next_state_cate_fea_col=prefix+next_state_cate_fea_col

                cur_state_cate_fea_col=tf.map_fn(lambda x: tf.string_join([prefix,x],separator='_'),cur_state_cate_fea_col )
                #next_state_cate_fea_col=tf.map_fn(lambda x: tf.string_join([prefix,x],separator='_'),next_state_cate_fea_col )
                

                int_cur_state_cate_fea_col = tf.string_to_hash_bucket_strong(cur_state_cate_fea_col, vocab_size, [1005, 1070])
                #int_next_state_cate_fea_col = tf.string_to_hash_bucket_strong(next_state_cate_fea_col, vocab_size, [1005, 1070])

                if(use_dense_hashtable):
                    embed_cur_cate_fea_col = tf.nn.embedding_lookup_hashtable_v2(embedding_matrix, int_cur_state_cate_fea_col)
                    reshaped_embed_cur_cate_fea_col = tf.tile(tf.reshape(embed_cur_cate_fea_col, [-1, cate_fea_num * embed_dim, 1]),(1,1,prod_num))
                    #embed_next_cate_fea_col = tf.nn.embedding_lookup_hashtable_v2(embedding_matrix, int_next_state_cate_fea_col)
                    #reshaped_embed_next_cate_fea_col = tf.tile(tf.reshape(embed_next_cate_fea_col, [-1, cate_fea_num * embed_dim, 1]),(1,1,prod_num))
                else:
                    embed_cur_cate_fea_col = tf.nn.embedding_lookup(embedding_matrix, int_cur_state_cate_fea_col)
                    reshaped_embed_cur_cate_fea_col =tf.tile( tf.reshape(embed_cur_cate_fea_col, [-1, cate_fea_num * embed_dim, 1]),(1,1,prod_num))
                    #embed_next_cate_fea_col = tf.nn.embedding_lookup(embedding_matrix, int_next_state_cate_fea_col)
                    #reshaped_embed_next_cate_fea_col = tf.tile(tf.reshape(embed_next_cate_fea_col, [-1, cate_fea_num * embed_dim, 1 ]),(1,1,prod_num))


            epsilon = 0.0000000001
             # normalized_numerical_fea_col = (numerical_fea_col - num_fea_mean_vec) / (tf.sqrt(num_fea_var_vec) + epsilon)
            cur_state_dynamic_fea_col = (cur_state_dynamic_fea_col - cur_state_dynamic_mean_vec) / (
                        tf.sqrt(cur_state_dynamic_var_vec) + epsilon)

            # next state dynamic feature
            # next_state_dynamic_fea = (next_state_dynamic_fea_col - next_state_dynamic_mean_vec) / (
            #             tf.sqrt(next_state_dynamic_var_vec) + epsilon)


            if(use_cate_fea):
                current_state = tf.concat(
                    [
                        reshaped_embed_cur_cate_fea_col,
                        # normalized_numerical_fea_col,
                        cur_state_dynamic_fea_col
                    ],
                    axis=1
                )
                # next_state = tf.concat(
                #     [
                #         reshaped_embed_next_cate_fea_col,
                #         # normalized_numerical_fea_col,
                #         next_state_dynamic_fea
                #     ],
                #     axis=1
                # )
            else:
                current_state = tf.concat(
                    [
                        # reshaped_embed_cur_cate_fea_col,
                        # normalized_numerical_fea_col,
                        cur_state_dynamic_fea_col
                    ],
                    axis=1
                )
                # next_state = tf.concat(
                #     [
                #         # reshaped_embed_next_cate_fea_col,
                #         # normalized_numerical_fea_col,
                #         next_state_dynamic_fea
                #     ],
                #     axis=1
                # )
        
            
        logger.info("---------------------------------")
        logger.info("---------------------------------")
        logger.info("current_state: {} , action:{},  reward:{}, is_terminal: {} ".format(current_state.get_shape(),action_col.get_shape(), reward.get_shape(),is_terminal.get_shape()))
        #  (?, 81, 4), next_state: (?, 81, 4) , action:(?, 4),  reward:(?, 4), is_terminal: (?,) 
        random_coeff = tf.constant(make_coeff(num_heads), tf.float32)
        # current_state 维度[state_fea_num, batch_size, -1, 4]
        total_q_logits ,total_q_imts,total_q_i= [],[],[]
        next_total_q_logits ,next_total_q_imts,next_total_q_i= [],[],[]
        q_vals, tar_q_vals = [], []
        q_best_actions, best_action_qvalues = [], []
        next_q_best_actions = []

        if use_adaptive:
            lambda_vector = get_calibration_vector(auto_lambda_vector) 
        else:
            lambda_vector = [None,None,None,None]
        # 每个agent有独立的q和i网络
        for i in range(4):
            with tf.variable_scope('train_agent_{}'.format(i)):
               
                if i == 3:
                    next_q_logit, next_q_imt, next_q_i = BCQ_net("target_{}".format(i), current_state[:, :, 0], deep_layers, num_action,use_bn,  use_rem,num_heads,random_coeff,
                                                                False, logger)
                    logger.info("  next_q_logit:{}, next_q_imt:{}, next_q_i:{}".format( next_q_logit.get_shape(), next_q_imt.get_shape(), next_q_i.get_shape()))
                    # next_q_logit:<unknown>, next_q_imt:(?, 20), next_q_i:(?, 20)
                    next_q_best_action, next_best_action_qvalue = select_action(next_q_logit, next_q_imt, threshold, use_bcq, lambda_vector[i])
                
                else:
                    next_q_logit, next_q_imt, next_q_i = BCQ_net("target_{}".format(i), current_state[:, :, i+1], deep_layers, num_action,use_bn,  use_rem,num_heads,random_coeff,
                                                                False, logger)
                    logger.info("  next_q_logit:{}, next_q_imt:{}, next_q_i:{}".format( next_q_logit.get_shape(), next_q_imt.get_shape(), next_q_i.get_shape()))
                    # next_q_logit:<unknown>, next_q_imt:(?, 20), next_q_i:(?, 20)
                    next_q_best_action, next_best_action_qvalue = select_action(next_q_logit, next_q_imt, threshold, use_bcq, lambda_vector[i])

                max_q_target = reward[:,i] + (1 - is_terminal[:,i]) * gamma * next_best_action_qvalue 

                tar_q_vals.append(max_q_target)
                next_q_best_actions.append(next_q_best_action)

                next_total_q_imts.append(next_q_imt)
                next_total_q_i.append(next_q_i)
                next_total_q_logits.append(next_q_logit)
                # Q
                random_coeff = tf.constant(make_coeff(params['num_heads']), tf.float32)
                q_logits, q_imt, q_i = BCQ_net("main_{}".format(i), current_state[:, :, i], deep_layers, num_action, use_bn, use_rem,
                                                            num_heads, random_coeff , True, logger)
                # action
                one_hot_action = tf.one_hot(indices=action_col[:, i], depth=num_action, dtype=tf.float32)
                qvalue = tf.reduce_sum(tf.multiply(q_logits , one_hot_action ), axis=1)

                q_vals.append(qvalue)

                total_q_imts.append(q_imt)
                total_q_i.append(q_i)
                total_q_logits.append(q_logits)

                q_best_action , best_action_qvalue = select_action(q_logits , q_imt , threshold, use_bcq)
              
                q_best_actions.append(q_best_action)
                best_action_qvalues.append(best_action_qvalue)
        
            # !list类型，n个agent的action和q value，拼接
            #[batch_size, 4, actions_dim]
        tar_q_vals = tf.concat([tf.expand_dims(tar_q_vals[i], axis=1) for i in range(4)], axis=1) # r + gamma * V(s_t+1)
        q_vals = tf.concat([tf.expand_dims(q_vals[i], axis=1) for i in range(4)], axis=1) # executed  Q value
    
        q_best_actions = tf.concat([tf.expand_dims(q_best_actions[i], axis=1) for i in range(4)], axis=1) # current state argmax action 
        best_action_qvalues = tf.concat([tf.expand_dims(best_action_qvalues[i], axis=1) for i in range(4)], axis=1) # q value for the above action
        next_q_best_actions = tf.concat([tf.expand_dims(next_q_best_actions[i], axis=1) for i in range(4)], axis=1) # q value for the next best action

        total_q_i = tf.concat([tf.expand_dims(total_q_i[i], axis=1) for i in range(4)], axis=1) # imitation current state Q value 
        total_q_logits = tf.concat([tf.expand_dims(total_q_logits[i], axis=1) for i in range(4)], axis=1)
        total_q_imts = tf.concat([tf.expand_dims(total_q_imts[i], axis=1) for i in range(4)], axis=1)

        next_total_q_i = tf.concat([tf.expand_dims(next_total_q_i[i], axis=1) for i in range(4)], axis=1) # imitation current state Q value 
        next_total_q_logits = tf.concat([tf.expand_dims(next_total_q_logits[i], axis=1) for i in range(4)], axis=1)
        next_total_q_imts = tf.concat([tf.expand_dims(next_total_q_imts[i], axis=1) for i in range(4)], axis=1)
    
            
        # or 直接取对应渠道的q
        logger.info("tar_q_vals:{}, q_vals:{},q_best_actions:{},best_action_qvalues:{},next_q_best_actions:{} ".format(tar_q_vals.get_shape(),q_vals.get_shape(),q_best_actions.get_shape(),best_action_qvalues.get_shape(),next_q_best_actions.get_shape()))
        #tar_q_vals:(?, 4, ?), q_vals:<unknown>,q_best_actions:(?, 4, 1),best_action_qvalues:(?, 4, 1),next_q_best_actions:(?, 4, 1) 
        logger.info("total_q_i:{}, total_q_logits:{}, total_q_imts:{}".format(total_q_i.get_shape(),total_q_logits.get_shape(),total_q_imts.get_shape()))
        # total_q_i:(?, 4, 20), total_q_logits:<unknown>, total_q_imts:(?, 4, 20)
        logger.info("next_total_q_i:{}, next_total_q_logits:{}, next_total_q_imts:{}".format(next_total_q_i.get_shape(),next_total_q_logits.get_shape(),next_total_q_imts.get_shape()))
        #next_total_q_i:(?, 4, 20), next_total_q_logits:<unknown>, next_total_q_imts:(?, 4, 20)


        logger.info("reward:{}".format(reward.get_shape()))
        # q_logits:<unknown>,q_value:<unknown>,q_imt:(?, 20),next_qnet_logits:<unknown>,next_qnet_imt:(?, 20)
        # reward:(?,)
        qnet_best_action, best_action_qvalue = q_best_actions,best_action_qvalues
        if mode == tf.estimator.ModeKeys.PREDICT:
            tf.identity(tf.cast(qnet_best_action, dtype=tf.float32))
            result = tf.concat([tf.cast(qnet_best_action,dtype=tf.float32),best_action_qvalue], axis=1, name="output_action")

            predictions = {
                "action": qnet_best_action,
                "qvalue": best_action_qvalue,
                "poi_id": poi_id,
                "cur_action": action_col
            }
            if ext_is_predict_serving == 1:
                return tf.estimator.EstimatorSpec(mode=mode, predictions=result)
            else:
                logger.info("offline predict")
                return tf.estimator.EstimatorSpec(mode=mode, predictions=predictions)

        current_action_reduce_dim = tf.squeeze(action_col)

        if use_batch_loss:
            with tf.name_scope("constraint"):
                target = [float(s) for s in params["constraint_target"].split("_")]
                constraint_weight = [float(s) for s in params["constraint_loss_weight"].split("_")]
            
                dj_actions = get_approx_action(total_q_logits[:,0,:],total_q_imts[:,0,:],total_q_i[:,0,:],use_bcq,threshold)
                bj_actions = get_approx_action(total_q_logits[:,1,:],total_q_imts[:,1,:],total_q_i[:,1,:],use_bcq,threshold)
                ss_actions = get_approx_action(total_q_logits[:,2,:],total_q_imts[:,2,:],total_q_i[:,2,:],use_bcq,threshold)
                push_actions =get_approx_action(total_q_logits[:,3,:],total_q_imts[:,3,:],total_q_i[:,3,:],use_bcq,threshold)
                
                actions_all = tf.concat([dj_actions,bj_actions,ss_actions,push_actions],dim=1)

                actions_cpc = reward / total_budgets *actions_all
                # cpc = click/cost 
                dj_actions_mean = tf.reduce_mean(actions_cpc[:,0])
                bj_actions_mean = tf.reduce_mean(actions_cpc[:,1])
                ss_actions_mean = tf.reduce_mean(actions_cpc[:,2])
                push_actions_mean = tf.reduce_mean(actions_cpc[:,3])
                
                dj_loss = get_constraint_loss(target=target[0], pred=dj_actions_mean)
                bj_loss = get_constraint_loss(target=target[1], pred=bj_actions_mean)
                ss_loss = get_constraint_loss(target=target[2], pred=ss_actions_mean)
                push_loss = get_constraint_loss(target=target[3], pred=push_actions_mean)

                all_constraint_loss = dj_loss*constraint_weight[0]+bj_loss*constraint_weight[1]+ss_loss*constraint_weight[2]+push_loss*constraint_weight[3]
               

        is_weights =tf.cast(tf.ones_like(action_col), tf.float32)  # 为后续增加权重做准备，当前是1
        i_loss = i_loss_weight * tf.reduce_mean(
            tf.multiply(
                is_weights,
                tf.expand_dims(tf.nn.sparse_softmax_cross_entropy_with_logits( # logits -> [batch_size, num_classes]，label -> [batch_size, 1]
                    labels=current_action_reduce_dim, logits=q_logits), axis=1)
            )
        )
        i_reg_loss = i_regularization_weight * tf.reduce_mean(
            tf.multiply(
                is_weights,
                tf.reduce_mean(tf.pow(q_logits, 2), axis=1)
            )
        )

        error = tf.reduce_mean(tf.abs(tar_q_vals - q_vals)) #[256,4] vs. [256]
        q_loss = q_loss_weight * Smooth_L1_Loss(tar_q_vals, q_vals, "loss", is_weights)

        logger.info('q_loss {}'.format(q_loss))
        logger.info('i_loss {}'.format(i_loss))
        logger.info('i_reg_loss {}'.format(i_reg_loss))
        all_loss = q_loss
        if use_bcq:
            all_loss = q_loss + i_loss + i_reg_loss
        if use_batch_loss:
            all_loss += all_constraint_loss
        
        logger.info('all_loss {}'.format(all_loss))
        
        main_qnet_var = []
        target_qnet_var = []
        for i in range(prod_num):
            main_qnet_var.append(tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='train_agent_{}/main_{}_net'.format(i,i)))
            target_qnet_var.append(tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='train_agent_{}/target_{}_net'.format(i,i)))

        qnet_next_action = best_action_qvalues

        tf.summary.scalar('qnet_next_action', tf.reduce_mean(tf.cast(qnet_next_action, tf.float32)))
        tf.summary.scalar('current_action', tf.reduce_mean(tf.cast(action_col, tf.float32)))
        tf.summary.scalar('qnet_best_action', tf.reduce_mean(tf.cast(qnet_best_action, tf.float32)))
        tf.summary.scalar('qvalue', tf.reduce_mean(qvalue))
        tf.summary.scalar('target_qvalue', tf.reduce_mean(max_q_target))
        tf.summary.scalar('best_action_qvalue', tf.reduce_mean(best_action_qvalue))
        tf.summary.scalar('reward', tf.reduce_mean(reward))
        tf.summary.scalar('loss', all_loss)
        tf.summary.scalar('q_loss', q_loss)
        tf.summary.scalar('i_loss', i_loss)
        tf.summary.scalar('i_reg_loss', i_reg_loss)
        tf.summary.scalar('abs_error', error)
        
        for i in range(4):
            logger.info(len(main_qnet_var[i]))
            logger.info(len(target_qnet_var[i]))
        all_main_var = main_qnet_var[0]+main_qnet_var[1]+main_qnet_var[2]+main_qnet_var[3]
        all_target_var = target_qnet_var[0]+target_qnet_var[1]+target_qnet_var[2]+target_qnet_var[3]

      
        pos_counter = tf.get_variable(
            'pos_counter',
            shape=[],
            dtype=tf.int64,
            initializer=tf.zeros_initializer(),
            trainable=False
        )
        neg_counter = tf.get_variable(
            'neg_counter',
            shape=[],
            dtype=tf.int64,
            initializer=tf.zeros_initializer(),
            trainable=False
        )

        global_step = tf.train.get_or_create_global_step()
        update_target_qnet_cond = is_update_target_qnet(global_step, update_interval)

        update_target_qnet_op = tf.cond(
            update_target_qnet_cond,
            true_fn=lambda: update_target_qnet(all_main_var, all_target_var, pos_counter),
            false_fn=lambda: do_nothing(neg_counter)
        )
        tf.summary.scalar('pos_counter', pos_counter)
        tf.summary.scalar('neg_counter', neg_counter)
        tf.summary.scalar('counter_ratio', pos_counter / (neg_counter + 1))

        update_op = [update_target_qnet_op]
        if use_adaptive:
            update_lambda_op= update_lambda_vector_multi_step_no_dependency(params,auto_lambda_vector,[total_q_logits,total_q_imts,total_q_i],total_budgets,lambda_budgets_target,use_bcq)
            update_op.append(update_lambda_op)

            lambda_pos_counter = tf.get_variable(
                'lambda_pos_counter',
                shape=[],
                dtype=tf.int64,
                initializer=tf.zeros_initializer(),
                trainable=False
            )
            lambda_neg_counter = tf.get_variable(
                'lambda_neg_counter',
                shape=[],
                dtype=tf.int64,
                initializer=tf.zeros_initializer(),
                trainable=False
            )
            update_target_lambda_cond = is_update_target_qnet(global_step, lambda_update_interval)

            update_target_lambda_op = tf.cond(
                update_target_lambda_cond,
                true_fn=lambda: update_target_lambda_vector(auto_lambda_vector, target_auto_lambda_vector, lambda_pos_counter),
                false_fn=lambda: do_nothing(lambda_neg_counter)
            )
            update_op.append(update_target_lambda_op)

        if mode == tf.estimator.ModeKeys.TRAIN:

            with tf.control_dependencies(update_op):
                var_diff = tf.add_n(
                    [tf.reduce_mean(tf.squared_difference(t, e)) for t, e in zip(all_main_var, all_target_var)])
                tf.summary.scalar('var_diff', tf.reduce_mean(var_diff))
                # train_op = HashAdamOptimizer(learning_rate=learning_rate).minimize(all_loss,global_step=global_step)
                train_op = tf.train.AdamOptimizer(learning_rate=learning_rate).minimize(all_loss,global_step=global_step)
            return tf.estimator.EstimatorSpec(mode=mode, loss=all_loss, train_op=train_op)

        return tf.estimator.EstimatorSpec(mode=mode, loss=all_loss)


def is_update_target_qnet(global_step, update_interval):
    ret = tf.equal(tf.mod(global_step, tf.constant(update_interval, dtype=tf.int64)), tf.constant(0, dtype=tf.int64))
    tf.summary.scalar("is_update_target_qnet", tf.cast(ret, tf.int32))
    return ret


def update_target_qnet(main_qnet_var, target_qnet_var, pos_counter):
    logger.info("all trainable vars: {}".format(tf.trainable_variables()))
    logger.info("main qnet vars: {}".format(main_qnet_var))
    logger.info("target qnet vars: {}".format(target_qnet_var))

    ops = [tf.assign_add(pos_counter, 1)]
    ops.extend([tf.assign(t, e) for t, e in zip(target_qnet_var, main_qnet_var)])
    update_op = tf.group(ops)
    return update_op


def do_nothing(neg_counter):
    ops = [tf.assign_add(neg_counter, 1), ]
    return tf.group(ops)


def train_function(loss, optimizer, global_step, learning_rate=0.001):
    with tf.name_scope('optimizer'):
        opt = get_optimizer_by_name(optimizer)(learning_rate)
    return opt.minimize(loss, global_step=global_step)



def update_target_lambda_vector(lambda_vector, target_lambda_vector, pos_counter):
    ops = [tf.assign_add(pos_counter, 1)]
    ops.extend([tf.assign(target_lambda_vector, lambda_vector)])
    update_op = tf.group(ops)
    return update_op


def is_update_auto_lambda(global_step, update_interval):
    ret = tf.equal(tf.mod(global_step, tf.constant(update_interval, dtype=tf.int64)), tf.constant(0, dtype=tf.int64))
    tf.summary.scalar("is_update_target_lambda", tf.cast(ret, tf.int32))
    return ret

# 生成线上tfserving的输入向量的格式
# 注意，placeholder的name需要和线上一致！！！！
def export_serving_model_input(params):
    cate_fea_num = params['cate_fea_num']
    state_fea_num = params['state_fea_num']

    feature_spec = {
        "prod": tf.placeholder(dtype=tf.float32, shape=[None, 1], name='dense_feature'),
        "poi_id": tf.placeholder(dtype=tf.int64, shape=[None, 1], name='poi_id'),
        "action": tf.placeholder(dtype=tf.int64, shape=[None, 4], name='action'),
        "is_terminal": tf.placeholder(dtype=tf.float32, shape=[None, 1], name='is_terminal'),
        "reward": tf.placeholder(dtype=tf.int64, shape=[None, 4], name='reward'),

        "cur_state_cate_fea": tf.placeholder(dtype=tf.string, shape=[None, cate_fea_num], name='cur_state_cate_fea'),
        "next_state_cate_fea": tf.placeholder(dtype=tf.string, shape=[None, cate_fea_num], name='next_state_cate_fea'),
        "cur_state_dynamic_fea": tf.placeholder(dtype=tf.float32, shape=[None, state_fea_num, 4], name='cur_state_fea'),
        "next_state_dynamic_fea": tf.placeholder(dtype=tf.float32, shape=[None, state_fea_num, 4], name='next_state_fea'),
 
    }
    serving_input_receiver_fn = tf.estimator.export.build_raw_serving_input_receiver_fn(feature_spec)
    return serving_input_receiver_fn


def estimator_save(estimator, params, log_dir):
    """ demo: estimator save """
    # save saved model
    serving_input_receiver_fn = export_serving_model_input(params)
    serving_model_path = log_dir
    logger.info("serving_model_path: {}".format(serving_model_path))
    estimator.export_savedmodel(serving_model_path, serving_input_receiver_fn=serving_input_receiver_fn)


def export_model_info(params):
    return params


def save_nn_model_info(params, model_info_file):
    model_info = export_model_info(params)
    json_data = json.dumps(model_info)
    fout = tf.gfile.Open(model_info_file, "w")
    fout.write(json_data)
    fout.close()


def custom_estimator(params, config):
    return tf.estimator.Estimator(
        model_fn=model_fn,
        params=params,
        config=config
    )

def get_constraint_loss(target, pred, le_loss=False):
    if le_loss:
        return tf.where(tf.less_equal(target, pred), tf.square(target - pred), 0.0)
    return tf.square(target - pred)


def update_lambda_vector_multi_step_no_dependency(config, lambda_vector, qnet_logits, total_budgets, target_real, use_bcq):
    # learning rate
    auto_lambda_alpha = [float(s) for s in config['lambda_alpha'].split("_")]
    auto_lambda_alpha = [tf.reshape(tf.convert_to_tensor(x), [1]) for x in auto_lambda_alpha]
    auto_lambda_alpha = tf.concat(auto_lambda_alpha, axis=0)
    op = tf.no_op()

    def _update_lambda_vector_once(lambda_vector_):
  
        calibration_vector = get_calibration_vector(lambda_vector_)
      
        qnet_logits_local, imt, i = qnet_logits
        actions_real,_ = select_action(qnet_logits_local, imt, i,use_bcq,calibration_vector,True)
        #actions_real = tf.map_fn(select_action,(qnet_logits_local, imt, i,use_bcq,calibration_vector),name='argmax')
        budgets = action_to_budgets(actions_real,total_budgets)

        real_mean = tf.reduce_mean(budgets,axis=-1)
        delta_lambda = auto_lambda_alpha*((real_mean - target_real)/target_real)

        delta_lambda = tf.Print(delta_lambda, [delta_lambda], "#delta_lambda=========", summarize=10)
        lambda_vector_ = tf.Print(lambda_vector_, [lambda_vector_], "#lambda_vector_", summarize=10)
        return lambda_vector_ + delta_lambda
    # multi_step update
    # qnet_logits = tf.stop_gradient(qnet_logits)
    iter_lambda_vector = lambda_vector
    for _ in range(int(config["lambda_update_num"])):
        iter_lambda_vector = _update_lambda_vector_once(iter_lambda_vector)

    op = tf.assign(lambda_vector, iter_lambda_vector)
    update_op = tf.group([op])
    return update_op


def approx_argmax_(x, epsilon=1e-10,approx_beta_rate=40.0):
    #  x -> [B,20]
    action_dim = tf.shape(x)[1]
    # x = x - tf.reduce_mean(x)
    cost = tf.range(0,tf.cast(action_dim, tf.float32))
    beta = float(approx_beta_rate)/(abs(tf.reduce_max(x)) + epsilon)
    exp_x = tf.exp(beta * x)
    return tf.reduce_sum(exp_x* cost/ tf.reduce_sum(exp_x))

def get_approx_action(qnet_logits, imt, i, use_bcq, threshold):
    if use_bcq:
        imt = tf.exp(imt)
        imt = (imt / tf.reduce_max(imt) > threshold)
        imt = tf.cast(imt, dtype=tf.float32)
        phase_qnet_logits = imt * qnet_logits + (1. - imt) * -1e8
    else:
        phase_qnet_logits = qnet_logits  
    # TODO: bcq的约束这样求解是否合适？
    approx_action = approx_argmax_(phase_qnet_logits)
    return approx_action


def z_score_norm(x, epsilon=1e-10):
    """
    z-score normalization
    :param x: input 1D Tensor
    :return: output 1D Tensor
    """
    mu = tf.reduce_mean(x)
    sigma = tf.sqrt(tf.reduce_mean(tf.square(x - mu)))
    return (x - tf.reduce_mean(x))/(sigma + epsilon)

def action_to_budgets(action,total_budgets,action_dim=20,prod_num=4):
    # [B,4], [B,4]
    logger.info("action:{},total_budgets:{}".format(action.get_shape(),total_budgets.get_shape()))
    percentage = tf.multiply(tf.cast(action,tf.float32),tf.constant(1./action_dim))
    real_budgets = percentage*total_budgets

    return real_budgets

def get_calibration_vector(predict_lambda=None):
    action_dim = 20
    if predict_lambda is None:
        predict_lambda = [0.0, 0.0, 0.0, 0.0]
    vector = []
    for phase_index in range(4):
        temp_vector = []
        for index in range(action_dim):
            temp_vector.append(predict_lambda[phase_index]*index/action_dim)
        vector.append(temp_vector)
    return vector