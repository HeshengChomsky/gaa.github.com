#!/usr/bin/env bash
set -x
set -u
set -o pipefail


table_name=${1}
predict_table_name=${2}
algorithm_name=${3}
batch_size=${4}
epoch=${5}
learning_rate=${6}
deep_layers=${7}
gamma=${8}
num_action=${9}
update_interval=${10}
embed_dim=${11}
bit=${12}
ext_is_predict_serving=${13}
use_bn=${14}
i_loss_weight=${15}
i_regularization_weight=${16}
q_loss_weight=${17}
num_heads=${18}
threshold=${19}
path_prefix=${20}
start_date=${21}
end_date=${22}
high_state_dynamic_fea=${23}
low_state_dynamic_fea=${24}
task=${25}
parameter_servers=${26}
workers=${27}
account=${28}
queue=${29}
with_chief=${30}
use_dense_hashtable=${31}
high_state_cate_fea=${32}
low_state_cate_fea=${33}
use_cate_fea=${34}
readFromHive=${35}
file_path=${36}
mod=${37}
hive_data=${38}
use_adaptive=${39}
use_batch_loss=${40}
lambda_alpha=${41}
lambda_update_interval=${42}
lambda_budgets_target=${43}
constraint_target=${44}
constraint_loss_weight=${45}

use_mask=${46}
use_bcorle=${47}
task_type=${48}
high_model_dir=${49}
remark=${50}
high_mean_var_dir=${51}

                        
########################################################
# 模型转换
case ${algorithm_name} in 
    "BCQ")
        use_bcq=True
        use_rem=False
        ;;
    "REM")
        use_bcq=False
        use_rem=True
        ;;
    "R-BCQ")
        use_bcq=True
        use_rem=True
        ;;
    "DQN")
        use_bcq=False
        use_rem=False
        ;;
    *)
        use_bcq=False
        use_rem=False
        ;;
esac

echo "use_bcq:${use_bcq}"
echo "use_rem:${use_rem}"


run_time=`date '+%Y-%m-%d_%H-%M-%S'`
model_name=${algorithm_name}_${remark}
model_hdfs=${path_prefix}/model/${end_date}/${model_name}/${task_type}

case ${use_cate_fea} in 
    "False")
        cur_state_cate_fea=""
        next_state_cate_fea=""
        ;;
esac


case ${task} in 
    "train")
        echo "delete model path: ${model_hdfs}"
        hdfs dfs -rm -r ${model_hdfs}
        ;;
esac
#####################################################################################
# calc mean_var for train data
output_prefix=mean_var_of_state

python -u util/cal_mean_var_for_num_features.py ${start_date} ${end_date} ${output_prefix} ${table_name} ${task_type} ${high_state_dynamic_fea} ${low_state_dynamic_fea}


low_state_dynamic_fea_mean_var='data/low_mean_var_of_state.'${end_date}
case ${task_type} in 
    "high")
        high_state_dynamic_fea_mean_var='data/high_mean_var_of_state.'${end_date}
        ;;
    "low")
        high_state_dynamic_fea_mean_var='data/low_mean_var_of_state.'${end_date}
        ;;
    *)
esac




#####################################################################################
# train
export HADOOP_HOME=/opt/meituan/hadoop

# 任务参数
# 可以选train/evaluate/train_eval/save
config_xml=dist.xml
is_dist=1


#数据参数

###############################################################################
#框架部分
export HADOOP_HOME=/opt/meituan/hadoop-gpu
export AFO_TF_HOME=/opt/meituan/tensorflow-release
tensorflow_submit=/opt/meituan/tensorflow-release/bin/tensorflow-submit.sh

train_data=${path_prefix}/train_tfrecoder/${end_date}
predict_data=${path_prefix}/predict_tfrecoder/${end_date}
predict_result_path=${path_prefix}/predict_result/${end_date}/${model_name}
echo "train_data: ${train_data}"
echo "predict_data: ${predict_data}"
echo "predict_result_path: ${predict_result_path}"

echo "origin task:${task}"
case ${task} in 
    "train")
        train_data=${train_data}
        ext_is_predict_serving=0
        ;;
    "predict")
        train_data=${predict_data}
        ext_is_predict_serving=0
        hdfs dfs -rm -r ${predict_result_path}
        hdfs dfs -mkdir ${path_prefix}/predict_result/
        hdfs dfs -mkdir ${path_prefix}/predict_result/${end_date}/
        hdfs dfs -mkdir ${path_prefix}/predict_result/${end_date}/${model_name}
        ;;
    "server")
        train_data=${train_data}
        ext_is_predict_serving=1
        hdfs dfs -rm -r ${predict_result_path}
        hdfs dfs -mkdir ${path_prefix}/predict_result/
        hdfs dfs -mkdir ${path_prefix}/predict_result/${end_date}/
        hdfs dfs -mkdir ${path_prefix}/predict_result/${end_date}/${model_name}
        task="predict"
        ;;
    *)
        train_data=${train_data}
        ;;
esac
echo "new task:${task}"

echo "train_data:${train_data}"
echo "predict_data:${predict_data}"
echo "ext_is_predict_serving:${ext_is_predict_serving}"


## 生成feature.json 文件
## python -u util/generate_feature_file.py ${cur_state_cate_fea} ${cur_state_dynamic_fea} ${next_state_cate_fea} ${next_state_dynamic_fea} data/feature.json


case ${mod} in 
    "local")
        hope run --xml conf/${config_xml} \
                --usergroup hadoop-hmart-waimaiad \
                -Dworker.memory=25600 \
                -Dafo.engine.wait_for_job_finished=true \
                -Ddistribute.mode=ps \
                --workbench \
                --ide \
                             -Dworker.script="python rl_code/main.py" \
                             -Dparameter.server.script="python rl_code/main.py" \
                             -Dchief.script="python rl_code/main.py" \
                             -Dboard.log_dir=${model_hdfs} \
                             -Dparameter.servers=${parameter_servers} \
                             -Dargs.ext_is_predict_serving=${ext_is_predict_serving} \
                             -Dworkers=${workers} \
                             -Dwith.chief=${with_chief} \
                             -Dafo.xm.notice.receivers.account=${account} \
                             -Dafo.app.name=${model_name} \
                             -Dqueue=${queue} \
                             -Dargs.log_dir=${model_hdfs} \
                             -Dargs.high_state_dynamic_fea_mean_var_filename=${high_state_dynamic_fea_mean_var} \
                             -Dargs.low_state_dynamic_fea_mean_var_filename=${low_state_dynamic_fea_mean_var} \
                             -Dargs.task=${task}  \
                             -Dargs.is_dist=${is_dist}  \
                             -Dargs.batch_size=${batch_size} \
                             -Dafo.data.max.epoch=${epoch} \
                             -Dargs.use_cate_fea=${use_cate_fea} \
                             -Dargs.bit=${bit} \
                             -Dargs.learning_rate=${learning_rate} \
                             -Dargs.embed_dim=${embed_dim} \
                             -Dargs.deep_layers=${deep_layers} \
                             -Dargs.gamma=${gamma} \
                             -Dargs.update_interval=${update_interval} \
                             -Dargs.use_rem=$use_rem \
                             -Dargs.use_bcq=$use_bcq \
                             -Dargs.use_bn=${use_bn} \
                             -Dargs.use_dense_hashtable=${use_dense_hashtable} \
                             -Dargs.i_loss_weight=${i_loss_weight} \
                             -Dargs.i_regularization_weight=${i_regularization_weight} \
                             -Dargs.q_loss_weight=${q_loss_weight} \
                             -Dargs.num_heads=${num_heads} \
                             -Dargs.threshold=${threshold} \
                             -Dargs.num_action=${num_action} \
                             -Dargs.predict_result_path=${predict_result_path} \
                             -Dargs.afo.app.support.engine.failover=true \
                             -Dargs.read_hive=${readFromHive} \
                             -Dargs.model_ckpt_dir=${model_hdfs} \
                             -Dargs.train_data=hive://${hive_data} \
                             -Dargs.use_adaptive=${use_adaptive} \
                             -Dargs.use_batch_loss=${use_batch_loss} \
                             -Dargs.lambda_alpha=${lambda_alpha} \
                             -Dargs.lambda_update_interval=${lambda_update_interval} \
                             -Dargs.lambda_budgets_target=${lambda_budgets_target} \
                             -Dargs.constraint_target=${constraint_target} \
                             -Dargs.constraint_loss_weight=${constraint_loss_weight} \
                             -Dargs.task_type=${task_type} \
                             -Dargs.use_bcorle=${use_bcorle} \
                             -Dargs.high_state_dynamic_fea=${high_state_dynamic_fea} \
                             -Dargs.low_state_dynamic_fea=${low_state_dynamic_fea} \
                             -Dargs.high_state_cate_fea=${high_state_cate_fea} \
                             -Dargs.low_state_cate_fea=${low_state_cate_fea} \
                             -Dargs.high_model_dir=${high_model_dir} \
                             -Dargs.use_mask=${use_mask} \
                             -Dargs.bcorle_lambda_num=${lambda_update_interval}

                ;;
       *)
           hope run --xml conf/${config_xml} \
                --usergroup hadoop-hmart-waimaiad \
                -Dworker.memory=25600 \
                -Dafo.engine.wait_for_job_finished=true \
                -Ddistribute.mode=ps \
                             -Dworker.script="python rl_code/main.py" \
                             -Dparameter.server.script="python rl_code/main.py" \
                             -Dchief.script="python rl_code/main.py" \
                             -Dboard.log_dir=${model_hdfs} \
                             -Dparameter.servers=${parameter_servers} \
                             -Dargs.ext_is_predict_serving=${ext_is_predict_serving} \
                             -Dworkers=${workers} \
                             -Dwith.chief=${with_chief} \
                             -Dafo.xm.notice.receivers.account=${account} \
                             -Dafo.app.name=${model_name} \
                             -Dqueue=${queue} \
                             -Dargs.log_dir=${model_hdfs} \
                             -Dargs.high_state_dynamic_fea_mean_var_filename=${high_state_dynamic_fea_mean_var} \
                             -Dargs.low_state_dynamic_fea_mean_var_filename=${low_state_dynamic_fea_mean_var} \
                             -Dargs.task=${task}  \
                             -Dargs.is_dist=${is_dist}  \
                             -Dargs.batch_size=${batch_size} \
                             -Dafo.data.max.epoch=${epoch} \
                             -Dargs.use_cate_fea=${use_cate_fea} \
                             -Dargs.bit=${bit} \
                             -Dargs.learning_rate=${learning_rate} \
                             -Dargs.embed_dim=${embed_dim} \
                             -Dargs.deep_layers=${deep_layers} \
                             -Dargs.gamma=${gamma} \
                             -Dargs.update_interval=${update_interval} \
                             -Dargs.use_rem=$use_rem \
                             -Dargs.use_bcq=$use_bcq \
                             -Dargs.use_bn=${use_bn} \
                             -Dargs.use_dense_hashtable=${use_dense_hashtable} \
                             -Dargs.i_loss_weight=${i_loss_weight} \
                             -Dargs.i_regularization_weight=${i_regularization_weight} \
                             -Dargs.q_loss_weight=${q_loss_weight} \
                             -Dargs.num_heads=${num_heads} \
                             -Dargs.threshold=${threshold} \
                             -Dargs.num_action=${num_action} \
                             -Dargs.predict_result_path=${predict_result_path} \
                             -Dargs.afo.app.support.engine.failover=true \
                             -Dargs.read_hive=${readFromHive} \
                             -Dargs.model_ckpt_dir=${model_hdfs} \
                             -Dargs.train_data=hive://${hive_data} \
                             -Dargs.use_adaptive=${use_adaptive} \
                             -Dargs.use_batch_loss=${use_batch_loss} \
                             -Dargs.lambda_alpha=${lambda_alpha} \
                             -Dargs.lambda_update_interval=${lambda_update_interval} \
                             -Dargs.lambda_budgets_target=${lambda_budgets_target} \
                             -Dargs.constraint_target=${constraint_target} \
                             -Dargs.constraint_loss_weight=${constraint_loss_weight} \
                             -Dargs.task_type=${task_type} \
                             -Dargs.use_bcorle=${use_bcorle} \
                             -Dargs.high_state_dynamic_fea=${high_state_dynamic_fea} \
                             -Dargs.low_state_dynamic_fea=${low_state_dynamic_fea} \
                             -Dargs.high_state_cate_fea=${high_state_cate_fea} \
                             -Dargs.low_state_cate_fea=${low_state_cate_fea} \
                             -Dargs.high_model_dir=${high_model_dir} \
                             -Dargs.use_mask=${use_mask} \
                             -Dargs.bcorle_lambda_num=${lambda_update_interval}
                ;;
esac
                
                    #  -Dafo.args.train_data=hive://${table_name} \
                    #  -Dafo.engine.tensorflow.virtualenv.name=mt_tensorflow \
                    #  -Dafo.app.virtualenv.version.mt_tensorflow.path=viewfs://hadoop-meituan/ghnn01/yarn/var/afo/tensorflow/virtualenv/release/tf1.15_mt1.2.0-centos6-cpu-venv.tar.gz \
################################################################# ads
