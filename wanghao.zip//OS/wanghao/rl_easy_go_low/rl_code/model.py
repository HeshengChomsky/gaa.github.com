#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2019-12-17 16:06
# @Author  : shaoguang.csg
# @File    : model_dataset

import imp
from re import S
import re
import tensorflow as tf
import numpy as np
import json
from util.util import *
from tensorflow.contrib.lookup.lookup_ops import  get_mutable_dense_hashtable
from nets import BCQ_net, Mix_net
# from tensorflow.contrib.opt import HashAdamOptimizer
from tensorflow.core.framework import types_pb2
from tensorflow_serving.apis import predict_pb2
import os
import sys
CURRENT_DIR = os.path.split(os.path.abspath(__file__))[0]  # 当前目录
config_path = CURRENT_DIR.rsplit('/', 2)[0]  # 上2级目录
sys.path.append(config_path)
# from rl_easy_go_high.rl_code.main import Trainer

logger = set_logger()

def load_normalization_parameter(mean_var_filename, fea_num, prod_num=4,use_bcorle=False):
    fea_mean = []
    fea_var = []
    input_file = tf.gfile.Open(mean_var_filename)
    for line in input_file:
        splitted = line.strip().split("\t")
        for i in range (len(splitted)):
            if splitted[i] == "NULL":
                splitted[i] = 1.0

        for i in range(fea_num):
            fea_mean.append(float(splitted[i]))
        for i in range(fea_num):
            fea_var.append(float(splitted[i + fea_num]))
        if use_bcorle:
            fea_mean.append(1.0)
            fea_var.append(1.0)
        break
    logger.info('num_fea_mean %s', fea_mean)
    logger.info('num_fea_var %s', fea_var)
   
    fea_mean = [[i for _ in range(prod_num)] for i in fea_mean]
    fea_var = [[i for _ in range(prod_num)] for i in fea_var]
    return fea_mean, fea_var



def ortho_init(scale=1.0):
    # belsopenai baselines 用到的初始化函数
    def _ortho_init(shape, dtype, partition_info=None):
        # lasagne ortho init for tf
        shape = tuple(shape)
        if len(shape) == 2:
            flat_shape = shape
        elif len(shape) == 4:  # assumes NHWC
            flat_shape = (np.prod(shape[:-1]), shape[-1])
        else:
            raise NotImplementedError
        a = np.random.normal(0.0, 1.0, flat_shape)
        u, _, v = np.linalg.svd(a, full_matrices=False)
        q = u if u.shape == flat_shape else v  # pick the one with the correct shape
        q = q.reshape(shape)
        return (scale * q[:shape[0], :shape[1]]).astype(np.float32)

    return _ortho_init


def make_coeff(num_heads):
    arr = np.random.uniform(low=0.0, high=1.0, size=num_heads)
    arr /= np.sum(arr)
    return arr
 

def inference_rbcq(name, state_, hidden_units_list, num_actions, use_bn, use_rem, num_heads, random_coeff,trainable):
    with tf.variable_scope(name + '_net'):
        net = state_
        if use_bn:
            net = tf.layers.batch_normalization(state_, axis=-1, momentum=0.99,
                                                epsilon=0.001,
                                                center=True,
                                                scale=True,
                                                beta_initializer=tf.zeros_initializer(),
                                                gamma_initializer=tf.ones_initializer(),
                                                moving_mean_initializer=tf.zeros_initializer(),
                                                moving_variance_initializer=tf.ones_initializer(),
                                                beta_regularizer=None,
                                                gamma_regularizer=None,
                                                beta_constraint=None,
                                                gamma_constraint=None,
                                                training=False,
                                                trainable=trainable,
                                                reuse=None,
                                                renorm=False,
                                                renorm_clipping=None,
                                                renorm_momentum=0.99,
                                                fused=None,
                                                name="bn"
                                                )
        with tf.variable_scope(name + 'q_net'):
            q_net = net
            for i in range(len(hidden_units_list)):
                q_net = tf.layers.dense(
                    inputs=q_net,
                    activation=tf.nn.relu,
                    units=hidden_units_list[i],
                    kernel_initializer=ortho_init(),
                    trainable=trainable,
                    name='fc_{idx}'.format(idx=i)
                )

            if use_rem:
                q = tf.layers.dense(q_net, num_actions * num_heads, activation=None, name="head_1", trainable=trainable)
                q = tf.reshape(q, (tf.shape(q_net)[0], num_actions, num_heads), name='head_2')
                q = tf.squeeze(tf.reduce_sum(q * tf.reshape(random_coeff, [1, 1, -1]), axis=2), name="head_q")
            else:
                q = tf.layers.dense(q_net, num_actions, activation=None, name="head_q", trainable=trainable)

        with tf.variable_scope(name + 'i_net'):
            # I network
            i_net = net
            for i in range(len(hidden_units_list)):
                i_net = tf.layers.dense(
                    inputs=i_net,
                    activation=tf.nn.relu,
                    units=hidden_units_list[i],
                    kernel_initializer=ortho_init(),
                    trainable=trainable,
                    name='fc_{idx}'.format(idx=i)
                )
            i = tf.layers.dense(i_net, num_actions, activation=None, name="i_o", trainable=trainable)
        imt = tf.nn.log_softmax(i)
    return q, imt, i


def Smooth_L1_Loss(labels, predictions, name, is_weights):
    with tf.variable_scope(name):
        diff = tf.abs(labels - predictions)
        less_than_one = tf.cast(tf.less(diff, 1.0), tf.float32)  # Bool to float32
        smooth_l1_loss = (less_than_one * 0.5 * diff ** 2) + (1.0 - less_than_one) * (diff - 0.5)
        return tf.reduce_mean(is_weights * smooth_l1_loss)  # get the average


def loss_function(y_logits, y_true):
    with tf.name_scope('loss'):
        cross_entropy_loss = tf.nn.sigmoid_cross_entropy_with_logits(
            labels=y_true,
            logits=y_logits,
            name='xentropy'
        )
        loss = tf.reduce_mean(cross_entropy_loss, name='xentropy_mean')
    return loss


optimizer_mapping = {
    "adam": tf.train.AdamOptimizer,
    "adadelta": tf.train.AdadeltaOptimizer,
    "adagrad": tf.train.AdagradOptimizer,
    "sgd": tf.train.GradientDescentOptimizer,
    "rmsprop": lambda lr: tf.train.RMSPropOptimizer(learning_rate=lr, momentum=0.95)
}


def get_optimizer_by_name(name):
    if name not in optimizer_mapping.keys():
        logger.error("Unsupported {} currently, using sgd as default".format(name))
        return optimizer_mapping["sgd"]
    return optimizer_mapping[name]


def select_action(q, imt, threshold, use_bcq):
    if use_bcq:
        imt = tf.exp(imt)
        imt = (imt / tf.reduce_max(imt, axis=1, keep_dims=True) >= threshold)
        imt = tf.cast(imt, dtype=tf.float32)
        return tf.reshape(tf.argmax(imt * q + (1. - imt) * -1e8, axis=1), [-1, 1]), tf.reshape(
            tf.reduce_max(imt * q + (1. - imt) * -1e8, axis=1), [-1, 1])
    else:
        imt = tf.exp(imt)
        imt = (imt / tf.reduce_max(imt, axis=1, keep_dims=True) >= 0)
        imt = tf.cast(imt, dtype=tf.float32)
        return tf.reshape(tf.argmax(imt * q + (1. - imt) * -1e8, axis=1), [-1, 1]), tf.reshape(
            tf.reduce_max(imt * q + (1. - imt) * -1e8, axis=1), [-1, 1])


def model_fn(features, labels, mode, params):
    vocab_size = params['vocab_size']
    state_fea_num = params['state_fea_num']
    deep_layers = params['deep_layers'].split(',')
    learning_rate = params['learning_rate']
    update_interval = params['update_interval']
    num_action = params['num_action']
    embed_dim = params['embed_dim']
    ext_is_predict_serving = params['ext_is_predict_serving']
    threshold = params['threshold']
    i_loss_weight = params['i_loss_weight']
    i_regularization_weight = params['i_regularization_weight']
    q_loss_weight = params['q_loss_weight']
    gamma = params['gamma']
    num_heads = params['num_heads']
    use_rem = params['use_rem']
    use_bcq = params['use_bcq']
    use_bn = params['use_bn']
    use_dense_hashtable=params['use_dense_hashtable']
    cate_fea_num = params['cate_fea_num']
    use_cate_fea=params['use_cate_fea']
    prod_num = params['prod_num']
    use_bcorle = params['use_bcorle']

    cur_state_dynamic_fea_mean_var_filename = params['cur_state_dynamic_fea_mean_var_filename']
    next_state_dynamic_fea_mean_var_filename = params['next_state_dynamic_fea_mean_var_filename']

    logger.info('cur_state_dynamic_fea_mean_var_filename {}'.format(cur_state_dynamic_fea_mean_var_filename))
    logger.info('next_state_dynamic_fea_mean_var_filename {}'.format(next_state_dynamic_fea_mean_var_filename))
    logger.info('params {}'.format(params))

    with tf.name_scope('model'):
        pvid = features['pvid']
        poi_id = features['poi_id']
        prod = tf.cast(features['prod'] , tf.int32)
        prod = tf.subtract(prod, 1)
        # state:[batch_size, prod_size, fea_num]
        if(use_cate_fea):
            cur_state_cate_fea_col = tf.cast(features['cur_state_cate_fea'],tf.string)
            next_state_cate_fea_col = tf.cast(features['next_state_cate_fea'],tf.string)
        cur_state_dynamic_fea_col = features['cur_state_dynamic_fea']
        next_state_dynamic_fea_col = features['next_state_dynamic_fea']

        reward = tf.cast(features['reward'], tf.float32)
        is_terminal = tf.cast(features['is_terminal'], tf.float32)
        logger.info('labels {}'.format(labels))
        action_col = tf.cast(features['action'],tf.int64)
        logger.info('action_col {}'.format(action_col))

        with tf.name_scope('dict'):
            # num_fea_mean_vec, num_fea_var_vec = load_normalization_parameter(
            #     num_fea_mean_var_filename,
            #     num_fea_num
            # )
            cur_state_dynamic_mean_vec, cur_state_dynamic_var_vec = load_normalization_parameter(
                cur_state_dynamic_fea_mean_var_filename,
                state_fea_num,
                prod_num,
                use_bcorle
            )
            next_state_dynamic_mean_vec, next_state_dynamic_var_vec = load_normalization_parameter(
                next_state_dynamic_fea_mean_var_filename,
                state_fea_num,
                prod_num,
                use_bcorle
            )
        if(use_cate_fea):
            with tf.name_scope('variable'):
                if(use_dense_hashtable):
                    print("get_mutable_dense_hashtable!!!!!!")
                    embedding_matrix = get_mutable_dense_hashtable(key_dtype=tf.int64,
                                                    value_dtype=tf.float32,
                                                    shape=tf.TensorShape([embed_dim]),
                                                    name="embed_table",
                                                    initializer=tf.truncated_normal_initializer(0.0, 1e-2),
                                                    shard_num=2)
                else:
                    print("get_variable!!!!!!")
                    embedding_matrix = tf.get_variable(
                            'embeddings',
                            shape=[vocab_size, embed_dim],
                            trainable=True,
                        )


        with tf.name_scope('input'):
            # poi static feature
            if(use_cate_fea):
                # id_prefix=tf.constant([[str(i) for i in range(cate_fea_num)] for j in range(shape[0])],dtype=tf.string)


                prefix = tf.constant([str(i)+"_"  for i in range(cate_fea_num)]) 
                # cur_state_cate_fea_col= prefix+cur_state_cate_fea_col
                # next_state_cate_fea_col=prefix+next_state_cate_fea_col

                cur_state_cate_fea_col=tf.map_fn(lambda x: tf.string_join([prefix,x],separator='_'),cur_state_cate_fea_col )
                next_state_cate_fea_col=tf.map_fn(lambda x: tf.string_join([prefix,x],separator='_'),next_state_cate_fea_col )
                

                int_cur_state_cate_fea_col = tf.string_to_hash_bucket_strong(cur_state_cate_fea_col, vocab_size, [1005, 1070])
                int_next_state_cate_fea_col = tf.string_to_hash_bucket_strong(next_state_cate_fea_col, vocab_size, [1005, 1070])

                if(use_dense_hashtable):
                    embed_cur_cate_fea_col = tf.nn.embedding_lookup_hashtable_v2(embedding_matrix, int_cur_state_cate_fea_col)
                    reshaped_embed_cur_cate_fea_col = tf.tile(tf.reshape(embed_cur_cate_fea_col, [-1, cate_fea_num * embed_dim, 1]),(1,1,prod_num))
                    embed_next_cate_fea_col = tf.nn.embedding_lookup_hashtable_v2(embedding_matrix, int_next_state_cate_fea_col)
                    reshaped_embed_next_cate_fea_col = tf.tile(tf.reshape(embed_next_cate_fea_col, [-1, cate_fea_num * embed_dim, 1]),(1,1,prod_num))
                else:
                    embed_cur_cate_fea_col = tf.nn.embedding_lookup(embedding_matrix, int_cur_state_cate_fea_col)
                    reshaped_embed_cur_cate_fea_col =tf.tile( tf.reshape(embed_cur_cate_fea_col, [-1, cate_fea_num * embed_dim, 1]),(1,1,prod_num))
                    embed_next_cate_fea_col = tf.nn.embedding_lookup(embedding_matrix, int_next_state_cate_fea_col)
                    reshaped_embed_next_cate_fea_col = tf.tile(tf.reshape(embed_next_cate_fea_col, [-1, cate_fea_num * embed_dim, 1 ]),(1,1,prod_num))


            epsilon = 0.0000000001
             # normalized_numerical_fea_col = (numerical_fea_col - num_fea_mean_vec) / (tf.sqrt(num_fea_var_vec) + epsilon)
            cur_state_dynamic_fea_col = (cur_state_dynamic_fea_col - cur_state_dynamic_mean_vec) / (
                        tf.sqrt(cur_state_dynamic_var_vec) + epsilon)

            # next state dynamic feature
            next_state_dynamic_fea = (next_state_dynamic_fea_col - next_state_dynamic_mean_vec) / (
                        tf.sqrt(next_state_dynamic_var_vec) + epsilon)


            if(use_cate_fea):
                current_state = tf.concat(
                    [
                        reshaped_embed_cur_cate_fea_col,
                        # normalized_numerical_fea_col,
                        cur_state_dynamic_fea_col
                    ],
                    axis=1
                )
                next_state = tf.concat(
                    [
                        reshaped_embed_next_cate_fea_col,
                        # normalized_numerical_fea_col,
                        next_state_dynamic_fea
                    ],
                    axis=1
                )
            else:
                current_state = tf.concat(
                    [
                        # reshaped_embed_cur_cate_fea_col,
                        # normalized_numerical_fea_col,
                        cur_state_dynamic_fea_col
                    ],
                    axis=1
                )
                next_state = tf.concat(
                    [
                        # reshaped_embed_next_cate_fea_col,
                        # normalized_numerical_fea_col,
                        next_state_dynamic_fea
                    ],
                    axis=1
                )
        
        # ! 获取上层predict信息：需要next, "reward_high"吗
        # with tf.name_scope('get_high_predict_result'):
        #     high_keys = ["ctr", "histctr", "final_charge", "aimcpc", "impr", "cpc", "revenue", "charge", "click", "order_num", "mt_butie", "impr_before1week", "click_before1week", "cpc_before1week", "order_num_before1week", "revenue_before1week", "mt_butie_before1week", "charge_before1week", "impr_before2week", "click_before2week", "cpc_before2week", "revenue_before2week", "charge_before2week", "order_num_before2week", "mt_butie_before2week", "impr_before3week", "cpc_before3week", "click_before3week", "order_num_before3week", "mt_butie_before3week", "revenue_before3week", "charge_before3week", "impr_before4week", "charge_before4week", "revenue_before4week", "mt_butie_before4week", "cpc_before4week", "click_before4week", "order_num_before4week", "budget", "goal"]
        #     high_keys += ["cur_state_cate_fea", "reward", "is_terminal"]
        #     dataset_high = dict()
        #     for i in high_keys:
        #         dataset_high[i] = features[i]
        #     # 调用estimator得到result
        #     result = Trainer.predict(low=True,dataset_low = dataset_high)
        #     goal = result['action'][0]
            
        logger.info("---------------------------------")
        logger.info("---------------------------------")
        logger.info("current_state: {}, next_state: {} , action:{},  reward:{}, is_terminal: {} ".format(current_state.get_shape(), next_state.get_shape(),action_col.get_shape(), reward.get_shape(),is_terminal.get_shape()))
        #  (?, 81, 4), next_state: (?, 81, 4) , action:(?, 4),  reward:(?, 4), is_terminal: (?,) 
        random_coeff = tf.constant(make_coeff(num_heads), tf.float32)
        # current_state 维度[state_fea_num, batch_size, -1, 4]
        total_q_logits ,total_q_imts,total_q_i= [],[],[]
        next_total_q_logits ,next_total_q_imts,next_total_q_i= [],[],[]
        q_vals, tar_q_vals = [], []
        q_best_actions, best_action_qvalues = [], []
        next_q_best_actions = []
        # 每个agent有独立的q和i网络
        for i in range(4):
            with tf.variable_scope('train_agent_{}'.format(i)):
                # Q_target, 输入state和observation
                # !obs设置, action 从q_value选对应值，设置多智能体环境中的多个action存放 [batch_size, 4, actions_dim]
                # next_state[:, :, i]是一个（batch_size, state_fea_dim）的tensor
                next_q_logit, next_q_imt, next_q_i = BCQ_net("target_{}".format(i), next_state[:, :, i], deep_layers, num_action,use_bn,  use_rem,num_heads,random_coeff,
                                                              False, logger)
                logger.info("  next_q_logit:{}, next_q_imt:{}, next_q_i:{}".format( next_q_logit.get_shape(), next_q_imt.get_shape(), next_q_i.get_shape()))
                # next_q_logit:<unknown>, next_q_imt:(?, 20), next_q_i:(?, 20)
                next_q_best_action, next_best_action_qvalue = select_action(next_q_logit, next_q_imt, threshold, use_bcq)
                max_q_target = reward[:,i] + (1 - is_terminal) * gamma * next_best_action_qvalue 
                tar_q_vals.append(max_q_target)
                next_q_best_actions.append(next_q_best_action)

                next_total_q_imts.append(next_q_imt)
                next_total_q_i.append(next_q_i)
                next_total_q_logits.append(next_q_logit)
                # Q
                random_coeff = tf.constant(make_coeff(params['num_heads']), tf.float32)
                q_logits, q_imt, q_i = BCQ_net("main_{}".format(i), current_state[:, :, i], deep_layers, num_action, use_bn, use_rem,
                                                            num_heads, random_coeff , True, logger)
                # action
                one_hot_action = tf.one_hot(indices=action_col[:, i], depth=num_action, dtype=tf.float32)
                qvalue = tf.reduce_sum(tf.multiply(q_logits , one_hot_action ), axis=1)

                q_vals.append(qvalue)

                total_q_imts.append(q_imt)
                total_q_i.append(q_i)
                total_q_logits.append(q_logits)

                q_best_action , best_action_qvalue = select_action(q_logits , q_imt , threshold, use_bcq)
              
                q_best_actions.append(q_best_action)
                best_action_qvalues.append(best_action_qvalue)
        
            # !list类型，n个agent的action和q value，拼接
            #[batch_size, 4, actions_dim]
        tar_q_vals = tf.stack(tar_q_vals,axis=1)
        q_vals =tf.stack(q_vals,axis=1) # executed  Q value
    
        q_best_actions =tf.stack(q_best_actions,axis=1) # current state argmax action 
        best_action_qvalues = tf.stack(best_action_qvalues,axis=1) # q value for the above action
        next_q_best_actions = tf.stack(next_q_best_actions,axis=1)# q value for the next best action

        total_q_i = tf.stack(total_q_i,axis=1) # imitation current state Q value 
        total_q_logits = tf.stack(total_q_logits,axis=1)
        total_q_imts = tf.stack(total_q_imts,axis=1)

        next_total_q_i = tf.stack(next_total_q_i,axis=1)# imitation current state Q value 
        next_total_q_logits = tf.stack(next_total_q_logits,axis=1)
        next_total_q_imts = tf.stack(next_total_q_imts,axis=1)
        # how to get q_logits? 
        # with tf.variable_scope(f'Mix_Q'):
        #     k, b = Mix_net(current_state, state_fea_num, True)
        #     total_q_logits = tf.squeeze(tf.add(tf.bmm(k, total_q_logits),b),axis=1) # k -> [bs, -1, 4] b ->[bs,1,1]
        #     # total_q_logits bs,1,actions_dims - > bs,actions_dims

        # with tf.name_scope('output'):
        #     one_hot_action = tf.one_hot(
        #         indices=action_col,
        #         depth=num_action,
        #         dtype=tf.float32
        #     )
        #     logger.info("one_hot_action:{}".format(one_hot_action))
        #     logger.info("qnet_logits:{}".format(q_logits[prod]))
        #     qvalue = tf.reduce_sum(tf.multiply(q_logits[prod], one_hot_action), axis=1)
            # qvalue = tf.squeeze(tf.matmul(one_hot_action, tf.expand_dims(qnet_logits, axis=-1)), axis=1,
            #                     name='current_q')
            
        # or 直接取对应渠道的q

        logger.info("tar_q_vals:{}, q_vals:{},q_best_actions:{},best_action_qvalues:{},next_q_best_actions:{} ".format(tar_q_vals.get_shape(),q_vals.get_shape(),q_best_actions.get_shape(),best_action_qvalues.get_shape(),next_q_best_actions.get_shape()))
        #tar_q_vals:(?, 4, ?), q_vals:<unknown>,q_best_actions:(?, 4, 1),best_action_qvalues:(?, 4, 1),next_q_best_actions:(?, 4, 1) 
        logger.info("total_q_i:{}, total_q_logits:{}, total_q_imts:{}".format(total_q_i.get_shape(),total_q_logits.get_shape(),total_q_imts.get_shape()))
        # total_q_i:(?, 4, 20), total_q_logits:<unknown>, total_q_imts:(?, 4, 20)
        logger.info("next_total_q_i:{}, next_total_q_logits:{}, next_total_q_imts:{}".format(next_total_q_i.get_shape(),next_total_q_logits.get_shape(),next_total_q_imts.get_shape()))
        #next_total_q_i:(?, 4, 20), next_total_q_logits:<unknown>, next_total_q_imts:(?, 4, 20)

        # 似乎可以用tf.where等价替换
        h_index = tf.reshape(prod,[-1,1])
        line = tf.reshape(tf.range(tf.shape(prod)[0]),[-1,1])
        index = tf.concat([line,h_index],axis = 1)

        logger.info("h_index:{}, line:{}, index:{}".format(h_index.get_shape(),line.get_shape(),index.get_shape()))
        # h_index:(?, 1), line:(?, 1), index:(?, 2)
    
        with tf.name_scope('output'):
            q_logits = tf.squeeze(tf.gather_nd(total_q_logits,index))
            q_value = tf.squeeze(tf.gather_nd(q_vals,index))
            q_imt = tf.squeeze(tf.gather_nd(total_q_imts,index))

            next_qnet_logits = tf.squeeze(tf.gather_nd(next_total_q_logits,index))
            next_qnet_imt = tf.squeeze(tf.gather_nd(next_total_q_imts,index))

            reward = tf.squeeze(tf.gather_nd(reward,index))

        logger.info("q_logits:{},q_value:{},q_imt:{},next_qnet_logits:{},next_qnet_imt:{}".format(q_logits.get_shape(),q_value.get_shape(),q_imt.get_shape(),next_qnet_logits.get_shape(),next_qnet_imt.get_shape()))
        logger.info("reward:{}".format(reward.get_shape()))
        # q_logits:<unknown>,q_value:<unknown>,q_imt:(?, 20),next_qnet_logits:<unknown>,next_qnet_imt:(?, 20)
        # reward:(?,)
        qnet_best_action, best_action_qvalue = select_action(q_logits, q_imt, threshold, use_bcq)
        if mode == tf.estimator.ModeKeys.PREDICT:
            tf.identity(tf.cast(qnet_best_action, dtype=tf.float32))
            result = tf.concat([tf.cast(qnet_best_action,dtype=tf.float32),best_action_qvalue], axis=1, name="output_action")

            predictions = {
                "action": qnet_best_action,
                "qvalue": best_action_qvalue,
                "poi_id": poi_id,
                "cur_action": action_col,
                "pvid": pvid
            }
            if ext_is_predict_serving == 1:
                return tf.estimator.EstimatorSpec(mode=mode, predictions=result)
            else:
                logger.info("offline predict")
                return tf.estimator.EstimatorSpec(mode=mode, predictions=predictions)

        action_col = tf.gather_nd(action_col,index)
        current_action_reduce_dim = tf.squeeze(action_col)

        is_weights =tf.cast(tf.ones_like(action_col), tf.float32)  # 为后续增加权重做准备，当前是1
        i_loss = i_loss_weight * tf.reduce_mean(
            tf.multiply(
                is_weights,
                tf.expand_dims(tf.nn.sparse_softmax_cross_entropy_with_logits( # logits -> [batch_size, num_classes]，label -> [batch_size, 1]
                    labels=current_action_reduce_dim, logits=q_logits), axis=1)
            )
        )
        i_reg_loss = i_regularization_weight * tf.reduce_mean(
            tf.multiply(
                is_weights,
                tf.reduce_mean(tf.pow(q_logits, 2), axis=1)
            )
        )

        next_qnet_best_action, next_best_action_qvalue = select_action(next_qnet_logits, next_qnet_imt, threshold,
                                                                       use_bcq)
        max_q_target = reward + (1 - is_terminal) * gamma * tf.squeeze(next_best_action_qvalue)
        logger.info("next_qnet_best_action:{},next_best_action_qvalue:{},max_q_target:{}".format(next_qnet_best_action.get_shape(),next_best_action_qvalue.get_shape(),max_q_target.get_shape()))
        # next_qnet_best_action:(?, 1),next_best_action_qvalue:(?, 1),max_q_target:(?, ?)
        logger.info("q_value:{}".format(q_value.get_shape()))
        # q_value:<unknown>
        error = tf.reduce_mean(tf.abs(max_q_target - q_value)) #[256,4] vs. [256]
        q_loss = q_loss_weight * Smooth_L1_Loss(q_value, max_q_target, "loss", is_weights)
        logger.info('q_loss {}'.format(q_loss))
        logger.info('i_loss {}'.format(i_loss))
        logger.info('i_reg_loss {}'.format(i_reg_loss))
        all_loss = q_loss
        if use_bcq:
            all_loss = q_loss + i_loss + i_reg_loss
        logger.info('all_loss {}'.format(all_loss))
        
        main_qnet_var = []
        target_qnet_var = []
        for i in range(prod_num):
            main_qnet_var.append(tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='train_agent_{}/main_{}_net'.format(i,i)))
            target_qnet_var.append(tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='train_agent_{}/target_{}_net'.format(i,i)))

        qnet_next_action = next_qnet_best_action

        tf.summary.scalar('qnet_next_action', tf.reduce_mean(tf.cast(qnet_next_action, tf.float32)))
        tf.summary.scalar('current_action', tf.reduce_mean(tf.cast(action_col, tf.float32)))
        tf.summary.scalar('qnet_best_action', tf.reduce_mean(tf.cast(qnet_best_action, tf.float32)))
        tf.summary.scalar('qvalue', tf.reduce_mean(qvalue))
        tf.summary.scalar('target_qvalue', tf.reduce_mean(max_q_target))
        tf.summary.scalar('best_action_qvalue', tf.reduce_mean(best_action_qvalue))
        tf.summary.scalar('reward', tf.reduce_mean(reward))
        tf.summary.scalar('loss', all_loss)
        tf.summary.scalar('q_loss', q_loss)
        tf.summary.scalar('i_loss', i_loss)
        tf.summary.scalar('i_reg_loss', i_reg_loss)
        tf.summary.scalar('abs_error', error)
        
        for i in range(4):
            logger.info(len(main_qnet_var[i]))
            logger.info(len(target_qnet_var[i]))
        all_main_var = main_qnet_var[0]+main_qnet_var[1]+main_qnet_var[2]+main_qnet_var[3]
        all_target_var = target_qnet_var[0]+target_qnet_var[1]+target_qnet_var[2]+target_qnet_var[3]
        # for i in range(prod_num):
        #     tf.summary.tensor_summary('main_qnet_var_{}'.format(i), main_qnet_var[i])
        #     tf.summary.tensor_summary('target_qnet_var_{}'.format(i), target_qnet_var[i])
        #logger.info("main_var:{}. tar_var:{}".format(all_main_var.get_shape(),all_target_var.get_shape()))


        pos_counter = tf.get_variable(
            'pos_counter',
            shape=[],
            dtype=tf.int64,
            initializer=tf.zeros_initializer(),
            trainable=False
        )
        neg_counter = tf.get_variable(
            'neg_counter',
            shape=[],
            dtype=tf.int64,
            initializer=tf.zeros_initializer(),
            trainable=False
        )

        global_step = tf.train.get_or_create_global_step()
        update_target_qnet_cond = is_update_target_qnet(global_step, update_interval)

        update_target_qnet_op = tf.cond(
            update_target_qnet_cond,
            true_fn=lambda: update_target_qnet(all_main_var, all_target_var, pos_counter),
            false_fn=lambda: do_nothing(neg_counter)
        )
        tf.summary.scalar('pos_counter', pos_counter)
        tf.summary.scalar('neg_counter', neg_counter)
        tf.summary.scalar('counter_ratio', pos_counter / (neg_counter + 1))

        if mode == tf.estimator.ModeKeys.TRAIN:
            with tf.control_dependencies([update_target_qnet_op]):
                var_diff = tf.add_n(
                    [tf.reduce_mean(tf.squared_difference(t, e)) for t, e in zip(all_main_var, all_target_var)])
                tf.summary.scalar('var_diff', tf.reduce_mean(var_diff))
                # train_op = HashAdamOptimizer(learning_rate=learning_rate).minimize(all_loss,global_step=global_step)
                train_op = tf.train.AdamOptimizer(learning_rate=learning_rate).minimize(all_loss,global_step=global_step)
            return tf.estimator.EstimatorSpec(mode=mode, loss=all_loss, train_op=train_op)

        return tf.estimator.EstimatorSpec(mode=mode, loss=all_loss)


def is_update_target_qnet(global_step, update_interval):
    ret = tf.equal(tf.mod(global_step, tf.constant(update_interval, dtype=tf.int64)), tf.constant(0, dtype=tf.int64))
    tf.summary.scalar("is_update_target_qnet", tf.cast(ret, tf.int32))
    return ret


def is_update_target_qnet1(time_step, total_steps):
    ret = tf.equal(time_step, total_steps)
    tf.summary.scalar("is_update_target_qnet", tf.cast(ret, tf.int32))
    return ret


def update_target_qnet(main_qnet_var, target_qnet_var, pos_counter):
    logger.info("all trainable vars: {}".format(tf.trainable_variables()))
    logger.info("main qnet vars: {}".format(main_qnet_var))
    logger.info("target qnet vars: {}".format(target_qnet_var))

    ops = [tf.assign_add(pos_counter, 1)]
    ops.extend([tf.assign(t, e) for t, e in zip(target_qnet_var, main_qnet_var)])
    update_op = tf.group(ops)
    return update_op


def do_nothing(neg_counter):
    ops = [tf.assign_add(neg_counter, 1), ]
    return tf.group(ops)


def train_function(loss, optimizer, global_step, learning_rate=0.001):
    with tf.name_scope('optimizer'):
        opt = get_optimizer_by_name(optimizer)(learning_rate)
    return opt.minimize(loss, global_step=global_step)


# 生成线上tfserving的输入向量的格式
# 注意，placeholder的name需要和线上一致！！！！
def export_serving_model_input(params):
    num_fea_num = params['num_fea_num']
    cate_fea_num = params['cate_fea_num']
    state_fea_num = params['state_fea_num']

    if params['use_bcorle']:
        state_fea_num += 1
    feature_spec = {
        "prod": tf.placeholder(dtype=tf.float32, shape=[None, 1], name='dense_feature'),
        "poi_id": tf.placeholder(dtype=tf.int64, shape=[None, 1], name='poi_id'),
        "pvid": tf.placeholder(dtype=tf.string, shape=[None, 1], name='pvid'),
        "action": tf.placeholder(dtype=tf.int64, shape=[None, 4], name='action'),
        "is_terminal": tf.placeholder(dtype=tf.float32, shape=[None, 1], name='is_terminal'),
        "reward": tf.placeholder(dtype=tf.int64, shape=[None, 4], name='reward'),

        "cur_state_cate_fea": tf.placeholder(dtype=tf.string, shape=[None, cate_fea_num], name='cur_state_cate_fea'),
        "next_state_cate_fea": tf.placeholder(dtype=tf.string, shape=[None, cate_fea_num], name='next_state_cate_fea'),
        "cur_state_dynamic_fea": tf.placeholder(dtype=tf.float32, shape=[None, state_fea_num, 4], name='cur_state_fea'),
        "next_state_dynamic_fea": tf.placeholder(dtype=tf.float32, shape=[None, state_fea_num, 4], name='next_state_fea'),
 
    }
    serving_input_receiver_fn = tf.estimator.export.build_raw_serving_input_receiver_fn(feature_spec)
    return serving_input_receiver_fn


def estimator_save(estimator, params, log_dir):
    """ demo: estimator save """
    # save saved model
    serving_input_receiver_fn = export_serving_model_input(params)
    serving_model_path = log_dir
    logger.info("serving_model_path: {}".format(serving_model_path))
    estimator.export_savedmodel(serving_model_path, serving_input_receiver_fn=serving_input_receiver_fn)


def export_model_info(params):
    return params


def save_nn_model_info(params, model_info_file):
    model_info = export_model_info(params)
    json_data = json.dumps(model_info)
    fout = tf.gfile.Open(model_info_file, "w")
    fout.write(json_data)
    fout.close()


def custom_estimator_low(params, config):
    return tf.estimator.Estimator(
        model_fn=model_fn,
        params=params,
        config=config
    )


